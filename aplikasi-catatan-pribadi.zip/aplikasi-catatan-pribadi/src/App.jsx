import React, { useState } from "react";
import NoteList from "./components/NoteList";
import AddNoteForm from "./components/AddNoteForm";
import { getInitialData } from "./utils/index";

// Komponen utama
function App() {
  const [notes, setNotes] = useState(getInitialData()); // fungsi useState untuk menyimpan

  // Fungsi untuk menambah catatan baru
  const addNote = (newNote) => {
    setNotes([...notes, newNote]); // Menambah catatan baru ke dalam array
    alert("Anda berhasil membuat Catatan Baru");
  };

  // Fungsi untuk menghapus catatan
  const deleteNote = (id) => {
    const isConfirm = window.confirm(
      "Apakah Anda benar-benar ingin menghapus Catatan ini?"
    );
    if (isConfirm) {
      // iwan purnama
      const filteredNotes = notes.filter((note) => note.id !== id);
      setNotes(filteredNotes);
      alert("Anda berhasil menghapus Catatan");
    }
  };

  // Fungsi untuk meng-Arsipkan Catatan
  const archiveNote = (id) => {
    const updatedNotes = notes.map((note) => {
      // fungsi map untuk menampilkan catatan pada NoteItem
      if (note.id === id) {
        return { ...note, archived: !note.archived };
      }
      return note;
    });
    setNotes(updatedNotes);
  };

  // memisahkan catatan yang diarsipkan
  const activeNotes = notes.filter((note) => !note.archived); // yang belum diarsipkan
  const archivedNotes = notes.filter((note) => note.archived); // sudah diarsipkan
  // iwan purnama
  return (
    <div className="app-container">
      <AddNoteForm onAdd={addNote} />

      <h3>Belum Diarsipkan</h3>
      <NoteList
        notes={activeNotes}
        onDelete={deleteNote}
        onArchive={archiveNote}
      />

      <h3>Catatan yang diarsipkan</h3>
      <NoteList // iwan purnama
        notes={archivedNotes}
        onDelete={deleteNote}
        onArchive={archiveNote}
      />
    </div>
  );
}

export default App;

import React from "react";
import { showFormattedDate } from "../utils/index";

// Komponen untuk menampilkan catatan
function NoteItem({
  // iwan purnama
  id,
  title,
  body,
  createdAt,
  archived,
  onDelete,
  onArchive,
}) {
  return (
    <div className="note-item">
      <h2>{title}</h2>
      <small>Diketik pada : {showFormattedDate(createdAt)}</small>
      <p>{body}</p>
      <div className="note-actions">
        <button className="delete-button" onClick={() => onDelete(id)}>
          Hapus
        </button>
        <button className="archive-button" onClick={() => onArchive(id)}>
          {archived ? "Kembalikan" : "Arsipkan"}
        </button>
      </div>
    </div>
  );
}

export default NoteItem;

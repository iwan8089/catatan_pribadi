import React, { useState } from "react";

// Komponen untuk menambah catatan
const AddNoteForm = ({ onAdd }) => {
  const [title, setTitle] = useState(""); // kolom untuk form judul
  const [body, setBody] = useState(""); // kolom untuk form isi catatan/content
  const [charCount, setCharCount] = useState(50); // membatasi judul tidak lebih dari 50 karakter

  // Fungsi untuk menangani Form
  const handleSubmit = (e) => {
    e.preventDefault(); // mencegah reload

    if (title.length === 0) {
      alert("Judul maksimal 50 Karakter");
      return;
    }
    // iwan purnama
    const newNote = {
      id: +new Date(), // ID unik menggunakan timestamp
      title,
      body,
      archived: false,
      createdAt: new Date().toISOString(),
    };
    onAdd(newNote); // Menambah catatan baru
    setTitle(""); // Reset form Judul
    setBody(""); // Reset form Isi Catatan Baru
    setCharCount(50); //setting karakter judul hanya 50 karakter saja
  };

  // Fungsi untuk menghitung jumlah karakter
  const handleTitleChange = (e) => {
    const inputTitle = e.target.value; // controlled components
    if (inputTitle.length <= 50) {
      setTitle(inputTitle);
      setCharCount(50 - inputTitle.length);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Notes</h2>
      <small>Sisa Karakter: {charCount}</small>
      <input
        type="text"
        placeholder="Judul Catatan (max. 50 karakter)" // iwan purnama
        value={title}
        onChange={handleTitleChange}
        required
      />
      <textarea
        placeholder="Isi Catatan"
        value={body}
        onChange={(e) => setBody(e.target.value)} // controlled components
        required
      ></textarea>
      <button type="submit">Buat Catatan Baru</button>
    </form>
  );
};

export default AddNoteForm;
